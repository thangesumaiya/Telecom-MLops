import joblib
import pandas as pd
model=joblib.load("telecom_tower_model.pkl")
new_data=pd.DataFrame({
    "Temperature_C":[500],
    "Battery_Voltage":[51],
    "Power_Consumption_W":[2335.5],
    "Signal_Strength_Percent":[50],
    "Fan_Speed_RPM":[3000],
    "Humidity_Percent":[81],
    "Traffic_Load":[4000],
    "Tower_Age_Years":[11]
    })
prediction=model.predict(new_data)
if prediction[0]==1:
    print("Hardware Failure Predicted")
else:
    print("Tower is Healthy")
    
    
